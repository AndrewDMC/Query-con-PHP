<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Nav Bar</title>
    <link rel="stylesheet" href="style/style_navbar.css">

</head>
<body>
    
    <header class="nav-bar">
        <a href="index.php" class="navElement">Home</a>
        <a href="classifica.php" class="navElement">Classifica</a>
        <a href="riepilogo.php" class="navElement">Riepilogo</a>
    </header>
    
    
</body>